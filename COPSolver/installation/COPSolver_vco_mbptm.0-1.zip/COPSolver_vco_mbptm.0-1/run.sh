#!/bin/sh
./config
sudo dpkg -i COPSolver_vco_mbptm.0-1.deb
copsolver-vco-mbptm
