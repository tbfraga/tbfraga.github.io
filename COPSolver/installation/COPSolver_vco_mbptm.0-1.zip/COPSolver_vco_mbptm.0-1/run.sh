#!/bin/sh
./config
sudo dpkg -i COPSolver_2.0-3.deb
copsolver
