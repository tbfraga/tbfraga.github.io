#!/bin/sh
./config
sudo dpkg -i COPSolver_vdpc_dpc.0-1.deb
copsolver-vdpc-dpc
