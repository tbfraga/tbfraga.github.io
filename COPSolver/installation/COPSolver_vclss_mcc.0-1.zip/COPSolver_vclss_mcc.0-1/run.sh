#!/bin/sh
./config
sudo dpkg -i COPSolver_vclss_mcc.0-1.deb
copsolver-vclss-mcc
